// Play — main app
// Manages screen state (landing -> chat), messages, mock bot responses.

function uid() { return Math.random().toString(36).slice(2, 9); }

function App() {
  const [screen, setScreen] = React.useState('landing'); // 'landing' | 'chat'
  const [messages, setMessages] = React.useState([]);
  const [input, setInput] = React.useState('');
  const [isTyping, setIsTyping] = React.useState(false);
  const [activeSession, setActiveSession] = React.useState(null);
  const scrollRef = React.useRef(null);

  // Auto-scroll on new message / typing change
  React.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    requestAnimationFrame(() => {
      el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
    });
  }, [messages, isTyping]);

  const startChat = (seed) => {
    setScreen('chat');
    setMessages([]);
    if (seed) {
      setTimeout(() => handleSend(seed), 220);
    }
  };

  const newChat = () => {
    setMessages([]);
    setInput('');
    setActiveSession(null);
  };

  const goHome = () => {
    setScreen('landing');
    setMessages([]);
    setInput('');
  };

  const handleSend = (forcedText) => {
    const text = (forcedText ?? input).trim();
    if (!text) return;
    const userMsg = { id: uid(), role: 'user', text };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsTyping(true);

    // Bot ack first
    setTimeout(() => {
      const campaign = window.pickCampaign(text);
      const botMsg = { id: uid(), role: 'bot', text: campaign.intro };
      setMessages(prev => [...prev, botMsg]);

      // Then "generates" campaign deck
      setTimeout(() => {
        const deckMsg = {
          id: uid(),
          role: 'campaign',
          campaign,
          onRegenerate: (platformKey) => {
            // toy regenerate: tiny ack message
          },
        };
        setMessages(prev => [...prev, deckMsg]);
        setIsTyping(false);
      }, 850);
    }, 1300);
  };

  const handleSuggestion = (label) => {
    handleSend(label);
  };

  // Edit mode (Tweaks) — expose two playful theme variants
  const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
    "vibe": "carnival",
    "showSidebar": true,
    "wobble": true
  }/*EDITMODE-END*/;

  const [tweaks, setTweaks] = React.useState(TWEAK_DEFAULTS);

  React.useEffect(() => {
    const onMsg = (e) => {
      const d = e.data;
      if (!d) return;
      if (d.type === '__activate_edit_mode') setEditOpen(true);
      else if (d.type === '__deactivate_edit_mode') setEditOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);

  const [editOpen, setEditOpen] = React.useState(false);

  const applyTweak = (patch) => {
    setTweaks(t => ({ ...t, ...patch }));
    window.parent.postMessage({ type: '__edit_mode_set_keys', edits: patch }, '*');
  };

  // Vibe variants flip CSS variables
  React.useEffect(() => {
    const root = document.documentElement;
    const palettes = {
      carnival: {
        '--cream': '#F7F1E3', '--cream-2': '#EFE8D3', '--paper': '#FFFDF6',
        '--tang': '#FF5B22', '--grape': '#9B5BFF', '--leaf': '#1FB364',
        '--sun': '#FFCB2E', '--ocean': '#3D7CFF', '--bubble': '#FF7AB6',
      },
      mint: {
        '--cream': '#EAF6EE', '--cream-2': '#D7ECDD', '--paper': '#F7FFF9',
        '--tang': '#FF6E61', '--grape': '#6C4BD8', '--leaf': '#0F9F6E',
        '--sun': '#F5D547', '--ocean': '#2D6CDF', '--bubble': '#FF93C7',
      },
      sunset: {
        '--cream': '#FFEDD8', '--cream-2': '#F7DFC1', '--paper': '#FFF8EE',
        '--tang': '#E63946', '--grape': '#7B3FBF', '--leaf': '#2B9A6A',
        '--sun': '#FFB627', '--ocean': '#1F6FB2', '--bubble': '#FF6BA3',
      },
    };
    const p = palettes[tweaks.vibe] || palettes.carnival;
    Object.entries(p).forEach(([k, v]) => root.style.setProperty(k, v));
  }, [tweaks.vibe]);

  return (
    <div className="grain-bg" style={{ minHeight: '100vh' }}>
      {screen === 'landing' ? (
        <window.Landing onStart={() => startChat()} />
      ) : (
        <div className="app-shell" style={tweaks.showSidebar ? {} : { gridTemplateColumns: '1fr' }}>
          {tweaks.showSidebar && (
            <window.Sidebar
              activeId={activeSession}
              onSelect={setActiveSession}
              onNewChat={newChat}
              onHome={goHome}
            />
          )}
          <main style={{ minWidth: 0 }}>
            <window.ChatScreen
              messages={messages}
              isTyping={isTyping}
              input={input}
              setInput={setInput}
              onSend={() => handleSend()}
              onSuggestion={handleSuggestion}
              scrollRef={scrollRef}
              onNewChat={newChat}
            />
          </main>
        </div>
      )}

      {/* Tweaks panel */}
      {editOpen && (
        <TweaksPanelInline
          tweaks={tweaks}
          setTweak={applyTweak}
          onClose={() => {
            setEditOpen(false);
            window.parent.postMessage({ type: '__edit_mode_dismissed' }, '*');
          }}
        />
      )}
    </div>
  );
}

function TweaksPanelInline({ tweaks, setTweak, onClose }) {
  const { Icon } = window;
  return (
    <div style={{
      position: 'fixed',
      right: 22, bottom: 22,
      width: 280,
      background: 'var(--paper)',
      border: '3px solid var(--ink)',
      borderRadius: 22,
      boxShadow: '8px 8px 0 var(--ink)',
      padding: '16px 18px',
      zIndex: 100,
      fontFamily: 'inherit',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 }}>
        <div style={{ fontWeight: 800, fontSize: 16, letterSpacing: '-0.02em' }}>Tweaks</div>
        <button onClick={onClose} style={{
          all: 'unset', cursor: 'pointer',
          width: 28, height: 28, borderRadius: 999, border: '2.5px solid var(--ink)',
          display: 'grid', placeItems: 'center', background: 'var(--cream-2)',
        }}><Icon.Close size={14} color="var(--ink)" /></button>
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <div className="mono" style={{ fontSize: 11, opacity: 0.6, marginBottom: 6 }}>VIBE</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['carnival', 'mint', 'sunset'].map(v => {
              const active = tweaks.vibe === v;
              return (
                <button key={v} onClick={() => setTweak({ vibe: v })} style={{
                  all: 'unset', cursor: 'pointer',
                  flex: 1, textAlign: 'center',
                  padding: '8px 6px',
                  border: '2.5px solid var(--ink)',
                  borderRadius: 12,
                  background: active ? 'var(--ink)' : 'var(--paper)',
                  color: active ? 'var(--paper)' : 'var(--ink)',
                  fontWeight: 700, fontSize: 13, textTransform: 'capitalize',
                }}>{v}</button>
              );
            })}
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontWeight: 700, fontSize: 14 }}>Show sidebar</span>
          <button onClick={() => setTweak({ showSidebar: !tweaks.showSidebar })} style={{
            all: 'unset', cursor: 'pointer',
            width: 44, height: 26, borderRadius: 999,
            border: '2.5px solid var(--ink)',
            background: tweaks.showSidebar ? 'var(--leaf)' : 'var(--cream-2)',
            position: 'relative',
          }}>
            <div style={{
              position: 'absolute', top: 1, left: tweaks.showSidebar ? 19 : 1,
              width: 19, height: 19, borderRadius: 999,
              background: 'var(--paper)', border: '2.5px solid var(--ink)',
              transition: 'left 180ms cubic-bezier(.34,1.56,.64,1)',
            }} />
          </button>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
