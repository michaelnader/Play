// Play — chat interface
// Centered chat, playful bubbles, big inviting input, suggestion chips, typing indicator.

function MessageBubble({ m, idx }) {
  const { Icon } = window;
  if (m.role === 'user') {
    return (
      <div className="anim-bubble" style={{
        alignSelf: 'flex-end',
        maxWidth: '72%',
        background: 'var(--ink)',
        color: 'var(--paper)',
        border: '3px solid var(--ink)',
        borderRadius: '26px 26px 6px 26px',
        padding: '14px 18px',
        fontSize: 17,
        lineHeight: 1.4,
        fontWeight: 500,
        boxShadow: '5px 5px 0 var(--tang)',
        transform: 'rotate(0.3deg)',
      }}>
        {m.text}
      </div>
    );
  }
  if (m.role === 'bot') {
    return (
      <div className="anim-bubble" style={{
        alignSelf: 'flex-start',
        maxWidth: '78%',
        display: 'flex',
        gap: 12,
        alignItems: 'flex-end',
      }}>
        <div style={{
          width: 44, height: 44,
          borderRadius: 14,
          border: '3px solid var(--ink)',
          background: 'var(--tang)',
          display: 'grid', placeItems: 'center',
          color: 'var(--paper)',
          fontWeight: 800, fontSize: 18,
          boxShadow: '3px 3px 0 var(--ink)',
          flexShrink: 0,
          transform: 'rotate(-4deg)',
        }} className="grainy">
          P
        </div>
        <div style={{
          background: 'var(--paper)',
          color: 'var(--ink)',
          border: '3px solid var(--ink)',
          borderRadius: '6px 26px 26px 26px',
          padding: '14px 18px',
          fontSize: 17,
          lineHeight: 1.4,
          fontWeight: 500,
          boxShadow: '5px 5px 0 var(--ink)',
          transform: 'rotate(-0.4deg)',
        }}>
          {m.text}
        </div>
      </div>
    );
  }
  if (m.role === 'campaign') {
    return (
      <div style={{ alignSelf: 'stretch', display: 'flex', flexDirection: 'column' }}>
        <window.CampaignDeck campaign={m.campaign} onRegenerate={m.onRegenerate} />
      </div>
    );
  }
  return null;
}

function TypingIndicator() {
  return (
    <div className="anim-bubble" style={{ alignSelf: 'flex-start', display: 'flex', alignItems: 'flex-end', gap: 12 }}>
      <div style={{
        width: 44, height: 44, borderRadius: 14,
        border: '3px solid var(--ink)',
        background: 'var(--tang)',
        display: 'grid', placeItems: 'center',
        color: 'var(--paper)', fontWeight: 800, fontSize: 18,
        boxShadow: '3px 3px 0 var(--ink)',
        transform: 'rotate(-4deg)',
      }} className="grainy anim-wobble">P</div>
      <div style={{
        background: 'var(--paper)',
        border: '3px solid var(--ink)',
        borderRadius: '6px 26px 26px 26px',
        padding: '16px 22px',
        boxShadow: '5px 5px 0 var(--ink)',
        display: 'flex', gap: 8, alignItems: 'center',
      }}>
        <span className="typing-dot" style={{ background: 'var(--tang)' }} />
        <span className="typing-dot" style={{ background: 'var(--grape)' }} />
        <span className="typing-dot" style={{ background: 'var(--ocean)' }} />
      </div>
    </div>
  );
}

function SuggestionChips({ onPick }) {
  const { Icon } = window;
  const iconMap = {
    rocket: Icon.Rocket, sprout: Icon.Sprout, tag: Icon.Tag, spark: Icon.Spark, bolt: Icon.Bolt,
  };
  return (
    <div style={{
      display: 'flex',
      gap: 10,
      flexWrap: 'wrap',
      justifyContent: 'center',
      marginBottom: 14,
    }}>
      {window.PLAY_SUGGESTIONS.map((s, i) => {
        const Ic = iconMap[s.icon] || Icon.Sparkle;
        return (
          <button
            key={s.label}
            className="chip"
            onClick={() => onPick(s.label)}
            style={{ background: s.color, color: 'var(--paper)' }}
          >
            <Ic size={16} color="var(--paper)" />
            {s.label}
          </button>
        );
      })}
    </div>
  );
}

function ChatInput({ value, onChange, onSend, disabled, placeholder }) {
  const { Icon } = window;
  const onKey = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      background: 'var(--paper)',
      border: '4px solid var(--ink)',
      borderRadius: 999,
      padding: '8px 8px 8px 26px',
      boxShadow: '6px 6px 0 var(--ink)',
      maxWidth: 820,
      width: '100%',
      margin: '0 auto',
      transition: 'transform 200ms cubic-bezier(.34,1.56,.64,1), box-shadow 200ms',
    }}
      onFocus={(e) => {
        e.currentTarget.style.transform = 'translate(-2px, -2px)';
        e.currentTarget.style.boxShadow = '8px 8px 0 var(--ink)';
      }}
      onBlur={(e) => {
        e.currentTarget.style.transform = 'translate(0,0)';
        e.currentTarget.style.boxShadow = '6px 6px 0 var(--ink)';
      }}
    >
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={onKey}
        placeholder={placeholder}
        disabled={disabled}
        style={{
          flex: 1,
          border: 'none',
          outline: 'none',
          fontSize: 18,
          fontWeight: 500,
          background: 'transparent',
          fontFamily: 'inherit',
          color: 'var(--ink)',
          padding: '12px 0',
        }}
      />
      <button
        onClick={onSend}
        disabled={disabled || !value.trim()}
        style={{
          width: 56, height: 56, borderRadius: 999,
          border: '3px solid var(--ink)',
          background: value.trim() && !disabled ? 'var(--tang)' : 'var(--cream-2)',
          color: 'var(--paper)',
          display: 'grid', placeItems: 'center',
          cursor: value.trim() && !disabled ? 'pointer' : 'not-allowed',
          boxShadow: '3px 3px 0 var(--ink)',
          transition: 'transform 180ms cubic-bezier(.34,1.56,.64,1), box-shadow 180ms, background 180ms',
        }}
        onMouseEnter={(e) => {
          if (value.trim() && !disabled) {
            e.currentTarget.style.transform = 'translate(-2px, -2px) rotate(-8deg)';
            e.currentTarget.style.boxShadow = '5px 5px 0 var(--ink)';
          }
        }}
        onMouseLeave={(e) => {
          e.currentTarget.style.transform = 'translate(0,0)';
          e.currentTarget.style.boxShadow = '3px 3px 0 var(--ink)';
        }}
      >
        <Icon.Send size={22} color={value.trim() && !disabled ? 'var(--paper)' : 'var(--ink)'} />
      </button>
    </div>
  );
}

function EmptyChatGreeting({ onPick }) {
  const { Shape, Icon } = window;
  return (
    <div className="anim-slide" style={{
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 22,
      padding: '40px 0 14px',
      textAlign: 'center',
    }}>
      <div className="anim-float" style={{ display: 'inline-block' }}>
        <Shape.Mascot color="var(--tang)" size={140} />
      </div>
      <div>
        <div style={{
          fontSize: 'clamp(36px, 4.4vw, 56px)',
          fontWeight: 800,
          letterSpacing: '-0.03em',
          lineHeight: 1.05,
        }}>
          What are we promoting <span className="sticker-underline">today</span>?
        </div>
        <div style={{ marginTop: 14, fontSize: 18, opacity: 0.7, maxWidth: 580, marginInline: 'auto' }}>
          Tell me about the product, audience, or vibe. The more specific, the better the campaign.
        </div>
      </div>
    </div>
  );
}

function ChatScreen({ messages, isTyping, input, setInput, onSend, onSuggestion, scrollRef, onNewChat }) {
  const empty = messages.length === 0;
  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      height: '100%',
      width: '100%',
      position: 'relative',
    }}>
      {/* Top thin bar inside chat area */}
      <div style={{
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        padding: '18px 36px',
        borderBottom: '3px solid var(--ink)',
        background: 'var(--cream)',
        zIndex: 3,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div className="grainy" style={{
            width: 38, height: 38, borderRadius: 12,
            background: 'var(--tang)', border: '3px solid var(--ink)',
            display: 'grid', placeItems: 'center', color: 'var(--paper)',
            fontWeight: 800, fontSize: 16, transform: 'rotate(-4deg)',
            boxShadow: '3px 3px 0 var(--ink)',
          }}>P</div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: '-0.02em' }}>Untitled jam</div>
            <div className="mono" style={{ fontSize: 11, opacity: 0.6 }}>auto-saved · just now</div>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="chip" onClick={onNewChat} style={{ background: 'var(--sun)' }}>
            <window.Icon.Plus size={15} color="var(--ink)" />
            New jam
          </button>
        </div>
      </div>

      {/* Scrolling chat area */}
      <div ref={scrollRef} style={{
        flex: 1,
        overflowY: 'auto',
        padding: '0 28px',
      }}>
        <div style={{
          maxWidth: 980,
          margin: '0 auto',
          display: 'flex',
          flexDirection: 'column',
          gap: 18,
          paddingTop: empty ? 0 : 28,
          paddingBottom: 28,
        }}>
          {empty && <EmptyChatGreeting onPick={onSuggestion} />}
          {messages.map((m, i) => <MessageBubble key={m.id} m={m} idx={i} />)}
          {isTyping && <TypingIndicator />}
        </div>
      </div>

      {/* Input dock */}
      <div style={{
        padding: '14px 28px 28px',
        background: 'linear-gradient(to top, var(--cream) 70%, rgba(247,241,227,0))',
      }}>
        {empty && <SuggestionChips onPick={onSuggestion} />}
        <ChatInput
          value={input}
          onChange={setInput}
          onSend={onSend}
          disabled={isTyping}
          placeholder={empty ? "e.g. launching a new oat milk for indie cafés…" : "keep the conversation going…"}
        />
        <div className="mono" style={{ textAlign: 'center', marginTop: 10, fontSize: 11, opacity: 0.55 }}>
          Press <kbd style={{ border: '2px solid var(--ink)', borderRadius: 6, padding: '0 6px', fontFamily: 'inherit' }}>Enter</kbd> to send · Play improvises — always double-check before posting.
        </div>
      </div>
    </div>
  );
}

window.ChatScreen = ChatScreen;
